# webpage_read_time


calculate time required to read a webpage. calculated time is approximated on basis of normal human reading speed.
currently working in linux environment.

to use this,
1. download file named "read_time.zip".
2. extract file.
3. go to the folder named "read_time".
4. open this folder in terminal.
5 type "./read time webpage_name
    example
    
    ./read_time https://en.wikipedia.org/wiki/Human
    
