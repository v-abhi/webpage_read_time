
#include <stdio.h>
#include <stdlib.h> // For exit()
#include <string.h>


// modified


int main(int argc, char **argv)
{
    FILE *fptr;
    FILE *fptr2;
    FILE *fptr3;

    char c,d,e,f;
    long int count = 0;
    int temp=0;
    int check=0;


    // Open file
    fptr = fopen("content.html", "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }
    fptr2 = fopen("content.html", "r");
    fptr3 = fopen("content.html", "r");



    // parsing <body> contents and avoiding <head> contents
    c = fgetc(fptr);
    d = fgetc(fptr2);
    d = fgetc(fptr2);
    e = fgetc(fptr3);
    e = fgetc(fptr3);
    e = fgetc(fptr3);
    while (c != EOF)
    {
        if(c=='b' && d=='o' && e=='d')
        {
          printf("found\n");
          check=1;
          break;
        }
        c = fgetc(fptr);
        d = fgetc(fptr2);
        e = fgetc(fptr3);
    }



    // if <body> content not found, then initializing from start
    if(check==0)
    {
      fptr = fopen("content.html", "r");
      if (fptr == NULL)
      {
          printf("Cannot open file \n");
          exit(0);
      }
    }
    // printing and counting chars in <body> contents
    c = fgetc(fptr);
    d = fgetc(fptr2);
    while (c != EOF)
    {
        c=fgetc(fptr);
        d = fgetc(fptr2);
        if(c=='>')
        {
          temp=1;
          c = fgetc(fptr);
          d = fgetc(fptr2);
        }
        if(c=='<')
        {
          temp=0;
          c = fgetc(fptr);
          d = fgetc(fptr2);
        }
        if(temp==1 && c!='\n')
        {
            //printf ("%c", c);
        }
        if(temp==1 && (c==' ' || c=='<') && d!=' ')
        {
          count++;
        }

    }
    printf("\nno.of words = %ld\n",count);


    fclose(fptr);
    return 0;
}






















/*
int main()
{
    FILE *fptr;

    char filename[100], c;

    printf("Enter the filename to open \n");
    scanf("%s", filename);

    // Open file
    fptr = fopen(filename, "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

    // Read contents from file
    c = fgetc(fptr);
    while (c != EOF)
    {
        printf ("%c", c);
        c = fgetc(fptr);
    }


    fclose(fptr);
    return 0;
}
*/




